let BudgetItem = require('./project_3_BudgetItem');//import BudgetItem class

class Expense extends BudgetItem {//Create Expense class which extends BudgetItem
    //Create constructor function for Expense class
    constructor (amount, month, year, destination, spender) {
        super(amount, month, year);//Call constructor of super class
        //Create private variables for destination and spender 
        let __destination__;
        let __spender__;

        //Create getter and setter functions
        this.setDestination = function (destination) {
            __destination__ = destination;
        }
        this.setSpender = function(spender) {
            __spender__ = spender;
        }
        this.getDestination = function() {
            return __destination__;
        }
        this.getSpender = function () {
            return __spender__;
        }
        this.setDestination(destination);
        this.setSpender(spender);
    }
}

module.exports = Expense;//Export the expense class