let BudgetItem = require('./project_3_BudgetItem');

class Expense extends BudgetItem {
    constructor (amount, month, year, destination, spender) {
        super(amount, month, year);
        let __destination__;
        let __spender__;

        this.setDestination = function (destination) {
            __destination__ = destination;
        }
        this.setSpender = function(spender) {
            __spender__ = spender;
        }
        this.getDestination = function() {
            return __destination__;
        }
        this.getSpender = function () {
            return __spender__;
        }
        this.setDestination(destination);
        this.setSpender(spender);
    }
}

module.exports = Expense;