let BudgetItem = require('./project_3_BudgetItem');
let Expense = require('./project_3_Expense');
let Income = require('./project_3_Income');

class BudgetAnalysis {
    constructor() {
        let __budgetItems__ = [];

        this.getBudgetItems = function () {
            return __budgetItems__;
        }
        this.setBudgetItems = function (budgetItems) {
            __budgetItems__ = budgetItems;
        }
        this.pushItems = function(budgetItems) {
            __budgetItems__.push(budgetItems);
        }
    }

    returnObjectsByMonth (month, items) {
        let m = [];
        for (let i of items) {
            if (i.getMonth() == month) {
                m.push(i);
            }
        }
        return m;
    }

    returnObjectsByYear (year, items) {
        let y = [];
        for (let i of items) {
            if (i.getYear() == year){
                y.push(i);
            }
        }
        return y;
    }

    returnRevenueByYear (year, items) {
        let income = 0;
        let expense = 0;
        for (let i of items) {
            if(i instanceof Income && i.getYear() == year) {
                income += i.getAmount();
            }
            else if (i instanceof Expense && i.getYear() == year) {
                expense += i.getAmount();
            } 
        }
        return (income - expense);
    }

    returnRevenueByMonth (month, items) {
        let income = 0;
        let expense = 0;
        for (let i of items) {
            if(i instanceof Income && i.getMonth() == month) {
                income += i.getAmount();
            }
            else if (i instanceof Expense && i.getMonth() == month) {
                expense += i.getAmount();
            } 
        }
        return (income - expense);
    }
}

let budgetAnalysis = new BudgetAnalysis();
let item1 = new BudgetItem(3000,"Jan",2019);
let item2 = new BudgetItem(3500,"Jan",2018);
let item3 = new BudgetItem(4000,"Feb",2019);
let expense1 = new Expense(4000, "Mar", 2019, "Canada", "Smith");
let expense2 = new Expense(3000, "Mar", 2019, "France", "Williams");
let income1 = new Income(5000, "Mar", 2019, "Sales");
let income2 = new Income(5000, "Mar", 2019, "Interest Income");

budgetAnalysis.pushItems(item1);
budgetAnalysis.pushItems(item2);
budgetAnalysis.pushItems(item3);
budgetAnalysis.pushItems(expense1);
budgetAnalysis.pushItems(expense2);
budgetAnalysis.pushItems(income1);
budgetAnalysis.pushItems(income2);

//uncomment console.log comments to test if the output is correct

//console.log(budgetAnalysis.getBudgetItems());
// console.log(" ");
// console.log(budgetAnalysis.returnObjectsByMonth("Jan", budgetAnalysis.getBudgetItems()));
// console.log(" ");
// console.log(budgetAnalysis.returnObjectsByYear(2019, budgetAnalysis.getBudgetItems()));
// console.log(budgetAnalysis.returnRevenueByYear(2019, budgetAnalysis.getBudgetItems()));
// console.log(budgetAnalysis.returnRevenueByMonth("Mar", budgetAnalysis.getBudgetItems()));

module.exports = BudgetAnalysis;
