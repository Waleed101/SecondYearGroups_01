//Import the BudgetItem, Expense and Income class
let BudgetItem = require('./project_3_BudgetItem');
let Expense = require('./project_3_Expense');
let Income = require('./project_3_Income');

class BudgetAnalysis {//Create a class to analyze the budget
    constructor() {
        //in the constructor, intitialize an empty array that will hold the budget items
        let __budgetItems__ = [];

        this.getBudgetItems = function () {//Returns the budget items
            return __budgetItems__;
        }
        this.setBudgetItems = function (budgetItems) {//Sets the budget items
            __budgetItems__ = budgetItems;
        }
        this.pushItems = function(budgetItems) {//Add a budget items to list of budget items
            __budgetItems__.push(budgetItems);
        }
    }
    //Return a list of Budget Items that have the same month
    returnObjectsByMonth (month, items) {//Pass in a month and array of items
        let m = [];//Create an empty temporary array
        for (let i of items) {//Implement a foreach loop to traverse the items array
            if (i.getMonth() == month) {//if the month of the item is equal to the passed item value
                m.push(i);//add the item to the temporary array m
            }
        }
        return m;//Return the array of items that have the same month
    }
    //Return a list of Budget Items that have the same year
    returnObjectsByYear (year, items) {//Pass in a year and array of items
        let y = [];//Create an empty temporary array
        for (let i of items) {//Implement a foreach loop to traverse the items array
            if (i.getYear() == year){//if the year of the item is equal to the passed year
                y.push(i);//Add the item to the temporary array y
            }
        }
        return y;//Return the array of items that have the same year
    }
    
    //Create a method to return the revenue in a specific year
    returnRevenueByYear (year, items) {//Pass in a year and array of items
        //Create income and expense variable to hold the total value of each
        let income = 0;
        let expense = 0;
        for (let i of items) {//Implement a foreach loop to traverse the items array
            //If the item is an instance of income and the year of the item is equal to the passed year
            if(i instanceof Income && i.getYear() == year) {
                income += i.getAmount();//add the amount of the item to the income variable
            }
            //If the item is an instance of expense and the year of the item is equal to the passed year
            else if (i instanceof Expense && i.getYear() == year) {
                expense += i.getAmount();//add the amount of the item to the expense variable
            } 
        }
        return (income - expense);//Return the difference between income and expense
    }

    //Create a method to return the revenue by month
    returnRevenueByMonth (month, items) {//Pass in a month and array of items
        //Create variables to hold the income and expense
        let income = 0;
        let expense = 0;
        for (let i of items) {//Create a foreach loop to traverse the array
            //If the item is an instance of income and the year of the item is equal to the passed year
            if(i instanceof Income && i.getMonth() == month) {
                income += i.getAmount();//add the amount of the item to the income variable
            }
            //If the item is an instance of expense and the year of the item is equal to the passed year
            else if (i instanceof Expense && i.getMonth() == month) {
                expense += i.getAmount();//add the amount of the item to the expense variable
            } 
        }
        return (income - expense);//Return the difference betweeen the income and expense
    }
}


let budgetAnalysis = new BudgetAnalysis();//Create a new BudgetAnalysis object
//Create a variety of objects that are of type BudgetItem, Expense, and Income
let item1 = new BudgetItem(3000,"Jan",2019);
let item2 = new BudgetItem(3500,"Jan",2018);
let item3 = new BudgetItem(4000,"Feb",2019);
let expense1 = new Expense(4000, "Mar", 2019, "Canada", "Smith");
let expense2 = new Expense(3000, "Mar", 2019, "France", "Williams");
let income1 = new Income(5000, "Mar", 2019, "Sales");
let income2 = new Income(5000, "Mar", 2019, "Interest Income");

//Add items to the budgetAnalysis object
budgetAnalysis.pushItems(item1);
budgetAnalysis.pushItems(item2);
budgetAnalysis.pushItems(item3);
budgetAnalysis.pushItems(expense1);
budgetAnalysis.pushItems(expense2);
budgetAnalysis.pushItems(income1);
budgetAnalysis.pushItems(income2);

//uncomment console.log comments to test if the output is correct

//console.log(budgetAnalysis.getBudgetItems());
// console.log(" ");
// console.log(budgetAnalysis.returnObjectsByMonth("Jan", budgetAnalysis.getBudgetItems()));
// console.log(" ");
// console.log(budgetAnalysis.returnObjectsByYear(2019, budgetAnalysis.getBudgetItems()));
// console.log(budgetAnalysis.returnRevenueByYear(2019, budgetAnalysis.getBudgetItems()));
// console.log(budgetAnalysis.returnRevenueByMonth("Mar", budgetAnalysis.getBudgetItems()));

module.exports = BudgetAnalysis;//Export the Budget Analysis class
