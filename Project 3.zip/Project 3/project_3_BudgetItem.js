class BudgetItem {
    constructor(amount,month,year) {
        let __amount__;
        let __month__;
        let __year__;

        this.setAmount = function (amount) {
            __amount__ = amount;
        }
        this.setMonth = function(month) {
            __month__ = month;
        }
        this.setYear = function (year) {
            __year__ = year;
        }
        this.getAmount = function() {
            return __amount__;
        }
        this.getMonth = function () {
            return __month__;
        }
        this.getYear = function () {
            return __year__;
        }
        this.setAmount(amount);
        this.setMonth(month);
        this.setYear(year);
    }
}

module.exports = BudgetItem;