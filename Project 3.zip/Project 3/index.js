BudgetItem = require('./project_3_BudgetItem');
Expense = require('./project_3_Expense');
Income = require('./project_3_Income');
BudgetAnalysis = require('./project_3_BudgetAnalysis');
budgets = require('./budget.json');
const fs = require('fs');

let transform = function(data) {
    let b;
    let budgetList = new BudgetAnalysis();
    for (let d of data) {
        switch(d.type) {
            case "":
                b = new BudgetItem(d.amount, d.month, d.year);
                break;
            case "expense":
                b = new Expense(d.amount, d.month, d.year, "Canada", "USA");
                break;
            case "income":
                b = new Income(d.amount, d.month, d.year, "Amazon");
        }
        budgetList.pushItems(b);
    }
    return budgetList;
}

let budgetList = transform(budgets)
let analysis2019 = {
    timestamp: 2019,
    revenue: budgetList.returnRevenueByYear(2019, budgetList.getBudgetItems())
}
let analysis2018 = {
    timestamp: 2018,
    revenue: budgetList.returnRevenueByYear(2018, budgetList.getBudgetItems())
}

let data = [analysis2018, analysis2019];
let yearlyData = JSON.stringify(data);

fs.writeFile('yearlyData.json', yearlyData, (err) => {
    if (err) {
        throw err;
    }
    console.log("JSON data is saved.");
});






































