//Import all the classes and json file of budget items
BudgetItem = require('./project_3_BudgetItem');
Expense = require('./project_3_Expense');
Income = require('./project_3_Income');
BudgetAnalysis = require('./project_3_BudgetAnalysis');
budgets = require('./budget.json');
const fs = require('fs');//Import the file system into the index.js file

//Create a transform function to convert the json objects from budget.json to either a BudgetItem, Expense or Income object
let transform = function(data) {
    let b;//Create a temporary variable to hold an object
    let budgetList = new BudgetAnalysis();//Create a new budgetAnalysis class
    for (let d of data) {//Implement a foreach loop to traverse through the json objects
        switch(d.type) {//Create a switch statement based on the type of the current object
            case ""://If type is empty
                b = new BudgetItem(d.amount, d.month, d.year);//Create a new Budget Item object
                break;
            case "expense"://If type is expense
                b = new Expense(d.amount, d.month, d.year, "Canada", "USA");//Create a new Expense object
                break;
            case "income"://If type is income
                b = new Income(d.amount, d.month, d.year, "Amazon");//Create a new Income object
        }
        budgetList.pushItems(b);//Push the temporary object b to the array contained in the budgetList object
    }
    return budgetList;//Return the budgetList object
}

let budgetList = transform(budgets)//Let budgetList equal the budgetList item from transform containing the list of budgetItems
//Create objects that contain the timestamp(year) and the revenue in that time
let analysis2019 = {
    timestamp: 2019,
    //Call the returnRevenueByYear function from the budgetAnalysis class to return the revenue in the given year(2019)
    revenue: budgetList.returnRevenueByYear(2019, budgetList.getBudgetItems())
}
let analysis2018 = {
    timestamp: 2018,
    //Call the returnRevenueByYear function from the budgetAnalysis class to return the revenue in the given year(2020)
    revenue: budgetList.returnRevenueByYear(2018, budgetList.getBudgetItems())
}

let data = [analysis2018, analysis2019];//Create a new array to hold the two analysis objects
let yearlyData = JSON.stringify(data);//Convert the data array to a JSON object

//Use the file system to create a new file called yearlyData which will hold the revenue for the years 2019 and 2018
fs.writeFile('yearlyData.json', yearlyData, (err) => {
    if (err) {
        throw err;
    }
    console.log("JSON data is saved.");
});






































