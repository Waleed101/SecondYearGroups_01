let BudgetItem = require('./project_3_BudgetItem');
class Income extends BudgetItem {
    constructor (amount, month, year, source) {
        super(amount, month, year);
        let __source__;

        this.setSource = function (source) {
            __source__ = source;
        }
        this.getSource = function () {
            return __source__;
        }
        this.setSource(source);
    }
}

module.exports = Income;