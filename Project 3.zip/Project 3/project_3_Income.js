let BudgetItem = require('./project_3_BudgetItem');//Import the BudgetItem class
class Income extends BudgetItem {//Create income class which extends BudgetItem
    constructor (amount, month, year, source) {//Create constructor function for Income class
        //Call constructor of super class
        super(amount, month, year);
        let __source__;//Create private variable for source of income
        
        //Create getter and setter functions to set the source
        this.setSource = function (source) {
            __source__ = source;
        }
        this.getSource = function () {
            return __source__;
        }
        this.setSource(source);
    }
}

module.exports = Income;//Export the income class